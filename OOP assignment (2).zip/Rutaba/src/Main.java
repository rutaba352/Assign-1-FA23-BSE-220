public class Main {
    public static void main(String[] args) {
        MessagingAppSystem app = new MessagingAppSystem();
        
        // Add contacts
        app.addContact("Rutaba Hayat");
        app.addContact("Alesha Yasin");

        // View contacts
        app.viewContacts();

        // Send messages
        app.sendMessage("Hello Rutaba!");
        app.sendMessage("Hey Alesha!");

        // View messages
        app.viewMessages();

        // Delete a message
        app.deleteMessage(0);

        // View messages after deletion
        app.viewMessages();

        // Delete a contact
        app.deleteContact(1);

        // View contacts after deletion
        app.viewContacts();
    }
}
