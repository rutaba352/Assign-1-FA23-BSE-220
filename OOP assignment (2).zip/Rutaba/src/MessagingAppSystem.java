import java.util.ArrayList;
public class MessagingAppSystem {
    private ArrayList<SMS> messages;
    private ArrayList<String> contacts;

    public MessagingAppSystem(){
        messages=new ArrayList<>();
        contacts=new ArrayList<>();
    }
    public void sendMessage(String content){
        SMS newMessage=new SMS(content);
        messages.add(newMessage);
        System.out.println("Message sent:"+content);

    }
    public void deleteMessage(int index){
        if(index>=0 && index<messages.size()){
            messages.remove(index);
            System.out.println("Message deleted at index"+index);
        }
    }
    public void addContact(String contact){
        contacts.add(contact);
        System.out.println("Contact added:"+contact);
    }
    public void deleteContact(int index){
        if (index >= 0 && index < contacts.size()) {
            contacts.remove(index);
            System.out.println("Contact deleted at index " + index);
        } else {
            System.out.println("Invalid index.");
        }
    }
    public void viewMessages(){
        if(messages.isEmpty()){
            System.out.println("No Message");
        }else{
            for(int i=0;i<messages.size();i++){
                System.out.println("Message"+i+":"+messages.get(i));
            }
        }
    }
    public void viewContacts(){
        if(contacts.isEmpty()){
            System.out.println("No contacts.");
        }else{
            for(int i=0;i<contacts.size();i++){
                System.out.println("Contact"+i+":"+contacts.get(i));
            }
        }
    }
}
