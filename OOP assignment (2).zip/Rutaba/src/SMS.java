import java.time.LocalDateTime;
public class SMS {
    private String content;
    private LocalDateTime dateTime;
    private String status;


    public SMS(String content){
        this.content=content;
        this.dateTime=LocalDateTime.now();
        this.status="unseen";
    }
    public String getContent(){
        return content;
    }
    public void setContent(String content){
        this.content=content;
    }
    public LocalDateTime getDateTime(){
        return dateTime;
    }
    public void setDateTime(LocalDateTime datetime){
        this.dateTime=datetime;
    }
    public String getStatus(){
        return status;
    }
    public void setStatus(String status){
        this.status=status;
    }
    @Override
    public String toString(){
        return "Message:"+ content +"\nDate"+dateTime+"\nStatus:"+status;
    }


}